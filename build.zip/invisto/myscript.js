function MyMenu1()  { 
//alert("begin1");

document.getElementById("li1").style="position: relative; left: 10%; background-color: #FF0000;";
document.getElementById("li2").style="position: relative; left: 25%;";
document.getElementById("li3").style="position: relative; left: 40%";
document.getElementById("li4").style="position: relative; left: 55%;";
document.getElementById("li5").style="position: relative; left: 70%;";
document.getElementById("li6").style="position: relative; left: 85%;";
  };

function MyMenu2()  { 
//alert("begin1");
document.getElementById("li1").style="position: relative; left: 10%; ";
document.getElementById("li2").style="position: relative; left: 25%; background-color: #FF0000;";
document.getElementById("li3").style="position: relative; left: 40%";
document.getElementById("li4").style="position: relative; left: 55%;";
document.getElementById("li5").style="position: relative; left: 70%;";
document.getElementById("li6").style="position: relative; left: 85%;";
  }; 

function MyMenu3()  { 
//alert("begin1");
document.getElementById("li1").style="position: relative; left: 10%; ";
document.getElementById("li2").style="position: relative; left: 25%; ";
document.getElementById("li3").style="position: relative; left: 40% ;background-color: #FF0000;  ";
document.getElementById("li4").style="position: relative; left: 55%;"
document.getElementById("li5").style="position: relative; left: 70%;"
document.getElementById("li6").style="position: relative; left: 85%;"

  };

function MyMenu4()  { 
//alert("begin1");
document.getElementById("li1").style="position: relative; left: 10%; ";
document.getElementById("li2").style="position: relative; left: 25%; ";
document.getElementById("li3").style="position: relative; left: 40% ;  ";
document.getElementById("li4").style="position: relative; left: 55%; background-color: #FF0000;  ";
document.getElementById("li5").style="position: relative; left: 70%;";
document.getElementById("li6").style="position: relative; left: 85%;";

  }; 

 function MyMenu5()  { 
//alert("begin1");
document.getElementById("li1").style="position: relative; left: 10%; ";
document.getElementById("li2").style="position: relative; left: 25%; ";
document.getElementById("li3").style="position: relative; left: 40% ;  ";
document.getElementById("li4").style="position: relative; left: 55%; ";
document.getElementById("li5").style="position: relative; left: 70%; background-color: #FF0000; ";
document.getElementById("li6").style="position: relative; left: 85%;";


  };

function MyMenu6()  { 
//alert("begin1");

document.getElementById("li1").style="position: relative; left: 10%; ";
document.getElementById("li2").style="position: relative; left: 25%; ";
document.getElementById("li3").style="position: relative; left: 40% ;  ";
document.getElementById("li4").style="position: relative; left: 55%; ";
document.getElementById("li5").style="position: relative; left: 70%; ";
document.getElementById("li6").style="position: relative; left: 85%; background-color: #FF0000;  ";

  }; 